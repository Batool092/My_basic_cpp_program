﻿namespace SnakeGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.lblScore = new System.Windows.Forms.Label();
            this.lblHighScore = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.picCanvas = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mniFormat = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColors = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsSnakeColor = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsSnakeColorWhite = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsSnakeColorYellow = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsSnakeColorRed = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsSnakeColorBlue = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsSnakeColorPurple = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsFoodColor = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsFoodColorWhite = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsFoodColorYellow = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsFoodColorBlue = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsFoodColorPurple = new System.Windows.Forms.ToolStripMenuItem();
            this.mniFormatColorsFoodColorRed = new System.Windows.Forms.ToolStripMenuItem();
            this.mniLevels = new System.Windows.Forms.ToolStripMenuItem();
            this.easyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mediumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mniGame = new System.Windows.Forms.ToolStripMenuItem();
            this.mniGamePause = new System.Windows.Forms.ToolStripMenuItem();
            this.mniGameResume = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlMainMenu = new System.Windows.Forms.Panel();
            this.btnInstructions = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblHead = new System.Windows.Forms.Label();
            this.pnlInstructions = new System.Windows.Forms.Panel();
            this.picSmile = new System.Windows.Forms.PictureBox();
            this.btnBackToMain = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblHeading = new System.Windows.Forms.Label();
            this.mniGameExit = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.mnuMain.SuspendLayout();
            this.pnlMainMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlInstructions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSmile)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 40;
            this.gameTimer.Tick += new System.EventHandler(this.GameTimerEvent);
            // 
            // lblScore
            // 
            this.lblScore.BackColor = System.Drawing.Color.Black;
            this.lblScore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.Color.Lime;
            this.lblScore.Location = new System.Drawing.Point(21, 130);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(250, 46);
            this.lblScore.TabIndex = 1;
            this.lblScore.Text = "SCORE : 0";
            this.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblScore.MouseEnter += new System.EventHandler(this.lblScore_MouseEnter);
            this.lblScore.MouseLeave += new System.EventHandler(this.lblScore_MouseLeave);
            // 
            // lblHighScore
            // 
            this.lblHighScore.BackColor = System.Drawing.Color.Black;
            this.lblHighScore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblHighScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHighScore.ForeColor = System.Drawing.Color.Lime;
            this.lblHighScore.Location = new System.Drawing.Point(754, 130);
            this.lblHighScore.Name = "lblHighScore";
            this.lblHighScore.Size = new System.Drawing.Size(307, 46);
            this.lblHighScore.TabIndex = 2;
            this.lblHighScore.Text = "HIGHEST SCORE : 0";
            this.lblHighScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHighScore.Click += new System.EventHandler(this.lblHighScore_Click);
            this.lblHighScore.MouseEnter += new System.EventHandler(this.lblHighScore_MouseEnter);
            this.lblHighScore.MouseLeave += new System.EventHandler(this.lblHighScore_MouseLeave);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnStart.BackColor = System.Drawing.Color.Black;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.Lime;
            this.btnStart.Location = new System.Drawing.Point(473, 656);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(221, 49);
            this.btnStart.TabIndex = 3;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.StartGame);
            this.btnStart.MouseEnter += new System.EventHandler(this.btnStart_MouseEnter);
            this.btnStart.MouseLeave += new System.EventHandler(this.btnStart_MouseLeave);
            // 
            // picCanvas
            // 
            this.picCanvas.BackColor = System.Drawing.Color.LightGray;
            this.picCanvas.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picCanvas.BackgroundImage")));
            this.picCanvas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCanvas.Location = new System.Drawing.Point(192, 200);
            this.picCanvas.Name = "picCanvas";
            this.picCanvas.Size = new System.Drawing.Size(750, 450);
            this.picCanvas.TabIndex = 4;
            this.picCanvas.TabStop = false;
            this.picCanvas.Click += new System.EventHandler(this.picCanvas_Click);
            this.picCanvas.Paint += new System.Windows.Forms.PaintEventHandler(this.UpdatePicBoxGraphics);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(297, 60);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // mnuMain
            // 
            this.mnuMain.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.mnuMain.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mniFormat,
            this.mniLevels,
            this.mniGame});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(1114, 40);
            this.mnuMain.TabIndex = 12;
            this.mnuMain.Text = "menuStrip1";
            this.mnuMain.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.mnuMain_ItemClicked);
            // 
            // mniFormat
            // 
            this.mniFormat.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mniFormatColors});
            this.mniFormat.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mniFormat.ForeColor = System.Drawing.Color.DarkGreen;
            this.mniFormat.Name = "mniFormat";
            this.mniFormat.Size = new System.Drawing.Size(111, 36);
            this.mniFormat.Text = "&Format";
            // 
            // mniFormatColors
            // 
            this.mniFormatColors.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mniFormatColorsSnakeColor,
            this.mniFormatColorsFoodColor});
            this.mniFormatColors.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mniFormatColors.Name = "mniFormatColors";
            this.mniFormatColors.Size = new System.Drawing.Size(179, 36);
            this.mniFormatColors.Text = "&Colors";
            // 
            // mniFormatColorsSnakeColor
            // 
            this.mniFormatColorsSnakeColor.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mniFormatColorsSnakeColorWhite,
            this.mniFormatColorsSnakeColorYellow,
            this.mniFormatColorsSnakeColorRed,
            this.mniFormatColorsSnakeColorBlue,
            this.mniFormatColorsSnakeColorPurple});
            this.mniFormatColorsSnakeColor.Name = "mniFormatColorsSnakeColor";
            this.mniFormatColorsSnakeColor.Size = new System.Drawing.Size(232, 36);
            this.mniFormatColorsSnakeColor.Text = "&Snake Color";
            // 
            // mniFormatColorsSnakeColorWhite
            // 
            this.mniFormatColorsSnakeColorWhite.ForeColor = System.Drawing.Color.Goldenrod;
            this.mniFormatColorsSnakeColorWhite.Name = "mniFormatColorsSnakeColorWhite";
            this.mniFormatColorsSnakeColorWhite.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsSnakeColorWhite.Text = "White";
            this.mniFormatColorsSnakeColorWhite.Click += new System.EventHandler(this.mniFormatColorsSnakeColorWhite_Click);
            // 
            // mniFormatColorsSnakeColorYellow
            // 
            this.mniFormatColorsSnakeColorYellow.ForeColor = System.Drawing.Color.Gold;
            this.mniFormatColorsSnakeColorYellow.Name = "mniFormatColorsSnakeColorYellow";
            this.mniFormatColorsSnakeColorYellow.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsSnakeColorYellow.Text = "Yellow";
            this.mniFormatColorsSnakeColorYellow.Click += new System.EventHandler(this.mniFormatColorsSnakeColorYellow_Click);
            // 
            // mniFormatColorsSnakeColorRed
            // 
            this.mniFormatColorsSnakeColorRed.ForeColor = System.Drawing.Color.Red;
            this.mniFormatColorsSnakeColorRed.Name = "mniFormatColorsSnakeColorRed";
            this.mniFormatColorsSnakeColorRed.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsSnakeColorRed.Text = "Red";
            this.mniFormatColorsSnakeColorRed.Click += new System.EventHandler(this.mniFormatColorsSnakeColorRed_Click);
            // 
            // mniFormatColorsSnakeColorBlue
            // 
            this.mniFormatColorsSnakeColorBlue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.mniFormatColorsSnakeColorBlue.Name = "mniFormatColorsSnakeColorBlue";
            this.mniFormatColorsSnakeColorBlue.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsSnakeColorBlue.Text = "Blue";
            this.mniFormatColorsSnakeColorBlue.Click += new System.EventHandler(this.mniFormatColorsSnakeColorBlue_Click);
            // 
            // mniFormatColorsSnakeColorPurple
            // 
            this.mniFormatColorsSnakeColorPurple.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.mniFormatColorsSnakeColorPurple.Name = "mniFormatColorsSnakeColorPurple";
            this.mniFormatColorsSnakeColorPurple.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsSnakeColorPurple.Text = "Purple";
            this.mniFormatColorsSnakeColorPurple.Click += new System.EventHandler(this.mniFormatColorsSnakeColorPurple_Click);
            // 
            // mniFormatColorsFoodColor
            // 
            this.mniFormatColorsFoodColor.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mniFormatColorsFoodColorWhite,
            this.mniFormatColorsFoodColorYellow,
            this.mniFormatColorsFoodColorBlue,
            this.mniFormatColorsFoodColorPurple,
            this.mniFormatColorsFoodColorRed});
            this.mniFormatColorsFoodColor.Name = "mniFormatColorsFoodColor";
            this.mniFormatColorsFoodColor.Size = new System.Drawing.Size(232, 36);
            this.mniFormatColorsFoodColor.Text = "&Food Color";
            // 
            // mniFormatColorsFoodColorWhite
            // 
            this.mniFormatColorsFoodColorWhite.ForeColor = System.Drawing.Color.Goldenrod;
            this.mniFormatColorsFoodColorWhite.Name = "mniFormatColorsFoodColorWhite";
            this.mniFormatColorsFoodColorWhite.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsFoodColorWhite.Text = "White";
            this.mniFormatColorsFoodColorWhite.Click += new System.EventHandler(this.mniFormatColorsFoodColorWhite_Click);
            // 
            // mniFormatColorsFoodColorYellow
            // 
            this.mniFormatColorsFoodColorYellow.ForeColor = System.Drawing.Color.Gold;
            this.mniFormatColorsFoodColorYellow.Name = "mniFormatColorsFoodColorYellow";
            this.mniFormatColorsFoodColorYellow.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsFoodColorYellow.Text = "Yellow";
            this.mniFormatColorsFoodColorYellow.Click += new System.EventHandler(this.mniFormatColorsFoodColorYellow_Click);
            // 
            // mniFormatColorsFoodColorBlue
            // 
            this.mniFormatColorsFoodColorBlue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.mniFormatColorsFoodColorBlue.Name = "mniFormatColorsFoodColorBlue";
            this.mniFormatColorsFoodColorBlue.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsFoodColorBlue.Text = "Blue";
            this.mniFormatColorsFoodColorBlue.Click += new System.EventHandler(this.mniFormatColorsFoodColorBlue_Click);
            // 
            // mniFormatColorsFoodColorPurple
            // 
            this.mniFormatColorsFoodColorPurple.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.mniFormatColorsFoodColorPurple.Name = "mniFormatColorsFoodColorPurple";
            this.mniFormatColorsFoodColorPurple.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsFoodColorPurple.Text = "Purple";
            this.mniFormatColorsFoodColorPurple.Click += new System.EventHandler(this.mniFormatColorsFoodColorPurple_Click);
            // 
            // mniFormatColorsFoodColorRed
            // 
            this.mniFormatColorsFoodColorRed.ForeColor = System.Drawing.Color.Red;
            this.mniFormatColorsFoodColorRed.Name = "mniFormatColorsFoodColorRed";
            this.mniFormatColorsFoodColorRed.Size = new System.Drawing.Size(181, 36);
            this.mniFormatColorsFoodColorRed.Text = "Red";
            this.mniFormatColorsFoodColorRed.Click += new System.EventHandler(this.mniFormatColorsFoodColorRed_Click);
            // 
            // mniLevels
            // 
            this.mniLevels.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.easyToolStripMenuItem,
            this.mediumToolStripMenuItem,
            this.hardToolStripMenuItem});
            this.mniLevels.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mniLevels.ForeColor = System.Drawing.Color.DarkGreen;
            this.mniLevels.Name = "mniLevels";
            this.mniLevels.Size = new System.Drawing.Size(99, 36);
            this.mniLevels.Text = "&Levels";
            // 
            // easyToolStripMenuItem
            // 
            this.easyToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.easyToolStripMenuItem.Name = "easyToolStripMenuItem";
            this.easyToolStripMenuItem.Size = new System.Drawing.Size(196, 36);
            this.easyToolStripMenuItem.Text = "&Easy";
            this.easyToolStripMenuItem.Click += new System.EventHandler(this.easyToolStripMenuItem_Click);
            // 
            // mediumToolStripMenuItem
            // 
            this.mediumToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.mediumToolStripMenuItem.Name = "mediumToolStripMenuItem";
            this.mediumToolStripMenuItem.Size = new System.Drawing.Size(196, 36);
            this.mediumToolStripMenuItem.Text = "&Medium";
            this.mediumToolStripMenuItem.Click += new System.EventHandler(this.mediumToolStripMenuItem_Click);
            // 
            // hardToolStripMenuItem
            // 
            this.hardToolStripMenuItem.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.hardToolStripMenuItem.Name = "hardToolStripMenuItem";
            this.hardToolStripMenuItem.Size = new System.Drawing.Size(196, 36);
            this.hardToolStripMenuItem.Text = "&Hard";
            this.hardToolStripMenuItem.Click += new System.EventHandler(this.hardToolStripMenuItem_Click);
            // 
            // mniGame
            // 
            this.mniGame.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mniGamePause,
            this.mniGameResume,
            this.mniGameExit});
            this.mniGame.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.mniGame.ForeColor = System.Drawing.Color.DarkGreen;
            this.mniGame.Name = "mniGame";
            this.mniGame.Size = new System.Drawing.Size(95, 36);
            this.mniGame.Text = "&Game";
            // 
            // mniGamePause
            // 
            this.mniGamePause.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.mniGamePause.Name = "mniGamePause";
            this.mniGamePause.Size = new System.Drawing.Size(270, 36);
            this.mniGamePause.Text = "&Pause";
            this.mniGamePause.Click += new System.EventHandler(this.mniGamePause_Click);
            // 
            // mniGameResume
            // 
            this.mniGameResume.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.mniGameResume.Name = "mniGameResume";
            this.mniGameResume.Size = new System.Drawing.Size(270, 36);
            this.mniGameResume.Text = "&Resume";
            this.mniGameResume.Click += new System.EventHandler(this.mniGameResume_Click);
            // 
            // pnlMainMenu
            // 
            this.pnlMainMenu.BackColor = System.Drawing.Color.DarkGray;
            this.pnlMainMenu.Controls.Add(this.btnInstructions);
            this.pnlMainMenu.Controls.Add(this.btnPlay);
            this.pnlMainMenu.Controls.Add(this.pictureBox2);
            this.pnlMainMenu.Controls.Add(this.lblHead);
            this.pnlMainMenu.Location = new System.Drawing.Point(0, 42);
            this.pnlMainMenu.Name = "pnlMainMenu";
            this.pnlMainMenu.Size = new System.Drawing.Size(1114, 705);
            this.pnlMainMenu.TabIndex = 13;
            // 
            // btnInstructions
            // 
            this.btnInstructions.BackColor = System.Drawing.Color.Black;
            this.btnInstructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstructions.Location = new System.Drawing.Point(460, 466);
            this.btnInstructions.Name = "btnInstructions";
            this.btnInstructions.Size = new System.Drawing.Size(244, 59);
            this.btnInstructions.TabIndex = 14;
            this.btnInstructions.Text = "INSTRUCTIONS";
            this.btnInstructions.UseVisualStyleBackColor = false;
            this.btnInstructions.Click += new System.EventHandler(this.btnInstructions_Click_1);
            // 
            // btnPlay
            // 
            this.btnPlay.BackColor = System.Drawing.Color.Black;
            this.btnPlay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.Location = new System.Drawing.Point(460, 355);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(244, 59);
            this.btnPlay.TabIndex = 13;
            this.btnPlay.Text = "PLAY";
            this.btnPlay.UseVisualStyleBackColor = false;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(174, 157);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(154, 107);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // lblHead
            // 
            this.lblHead.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHead.BackColor = System.Drawing.Color.Black;
            this.lblHead.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblHead.Font = new System.Drawing.Font("Algerian", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHead.ForeColor = System.Drawing.Color.Lime;
            this.lblHead.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblHead.Location = new System.Drawing.Point(172, 106);
            this.lblHead.Name = "lblHead";
            this.lblHead.Size = new System.Drawing.Size(833, 188);
            this.lblHead.TabIndex = 6;
            this.lblHead.Text = "     Snake Game";
            this.lblHead.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlInstructions
            // 
            this.pnlInstructions.BackColor = System.Drawing.Color.DarkGray;
            this.pnlInstructions.Controls.Add(this.picSmile);
            this.pnlInstructions.Controls.Add(this.btnBackToMain);
            this.pnlInstructions.Controls.Add(this.richTextBox1);
            this.pnlInstructions.Controls.Add(this.lblInstructions);
            this.pnlInstructions.Controls.Add(this.pictureBox3);
            this.pnlInstructions.Controls.Add(this.label1);
            this.pnlInstructions.Location = new System.Drawing.Point(0, 42);
            this.pnlInstructions.Name = "pnlInstructions";
            this.pnlInstructions.Size = new System.Drawing.Size(1112, 702);
            this.pnlInstructions.TabIndex = 15;
            this.pnlInstructions.Visible = false;
            this.pnlInstructions.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlInstructions_Paint);
            // 
            // picSmile
            // 
            this.picSmile.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picSmile.BackgroundImage")));
            this.picSmile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picSmile.Location = new System.Drawing.Point(754, 517);
            this.picSmile.Name = "picSmile";
            this.picSmile.Size = new System.Drawing.Size(81, 71);
            this.picSmile.TabIndex = 17;
            this.picSmile.TabStop = false;
            // 
            // btnBackToMain
            // 
            this.btnBackToMain.BackColor = System.Drawing.Color.Black;
            this.btnBackToMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackToMain.Location = new System.Drawing.Point(948, 614);
            this.btnBackToMain.Name = "btnBackToMain";
            this.btnBackToMain.Size = new System.Drawing.Size(120, 49);
            this.btnBackToMain.TabIndex = 16;
            this.btnBackToMain.Text = "Back";
            this.btnBackToMain.UseVisualStyleBackColor = false;
            this.btnBackToMain.Click += new System.EventHandler(this.btnBackToMain_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(134, 157);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(869, 447);
            this.richTextBox1.TabIndex = 14;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // lblInstructions
            // 
            this.lblInstructions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblInstructions.BackColor = System.Drawing.Color.Black;
            this.lblInstructions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblInstructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructions.ForeColor = System.Drawing.Color.Lime;
            this.lblInstructions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblInstructions.Location = new System.Drawing.Point(21, 104);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(216, 46);
            this.lblInstructions.TabIndex = 13;
            this.lblInstructions.Text = "Instructions:";
            this.lblInstructions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Black;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox3.Location = new System.Drawing.Point(285, 26);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 56);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(256, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(592, 69);
            this.label1.TabIndex = 6;
            this.label1.Text = "Snake Game";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeading
            // 
            this.lblHeading.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHeading.BackColor = System.Drawing.Color.Black;
            this.lblHeading.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.ForeColor = System.Drawing.Color.Lime;
            this.lblHeading.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblHeading.Location = new System.Drawing.Point(256, 57);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(594, 64);
            this.lblHeading.TabIndex = 5;
            this.lblHeading.Text = "Snake Game";
            this.lblHeading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mniGameExit
            // 
            this.mniGameExit.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.mniGameExit.Name = "mniGameExit";
            this.mniGameExit.Size = new System.Drawing.Size(270, 36);
            this.mniGameExit.Text = "&Exit";
            this.mniGameExit.Click += new System.EventHandler(this.mniGameExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(1114, 744);
            this.Controls.Add(this.pnlInstructions);
            this.Controls.Add(this.pnlMainMenu);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.picCanvas);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblHighScore);
            this.Controls.Add(this.lblScore);
            this.Controls.Add(this.mnuMain);
            this.ForeColor = System.Drawing.Color.Lime;
            this.MainMenuStrip = this.mnuMain;
            this.Name = "Form1";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.StartGame);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.KeyIsDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.KeyIsUp);
            ((System.ComponentModel.ISupportInitialize)(this.picCanvas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.pnlMainMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlInstructions.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picSmile)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblHighScore;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.PictureBox picCanvas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mniFormat;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColors;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsSnakeColor;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsFoodColor;
        private System.Windows.Forms.ToolStripMenuItem mniLevels;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsSnakeColorWhite;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsSnakeColorYellow;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsSnakeColorRed;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsSnakeColorBlue;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsSnakeColorPurple;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsFoodColorWhite;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsFoodColorYellow;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsFoodColorBlue;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsFoodColorPurple;
        private System.Windows.Forms.ToolStripMenuItem mniFormatColorsFoodColorRed;
        private System.Windows.Forms.ToolStripMenuItem easyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mediumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hardToolStripMenuItem;
        private System.Windows.Forms.Panel pnlMainMenu;
        private System.Windows.Forms.Label lblHead;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnInstructions;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Panel pnlInstructions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.Button btnBackToMain;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.PictureBox picSmile;
        private System.Windows.Forms.ToolStripMenuItem mniGame;
        private System.Windows.Forms.ToolStripMenuItem mniGamePause;
        private System.Windows.Forms.ToolStripMenuItem mniGameResume;
        private System.Windows.Forms.ToolStripMenuItem mniGameExit;
    }
}

