﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SnakeGame
{
   
    public partial class Form1 : Form
    {
        private List<Circle> Snake= new List<Circle>();
        private Circle Food= new Circle();

        int maxWidth;
        int maxHeight;

        int score;
        int Highscore;

        Random rand = new Random();
        bool goLeft, goRight, goUp, goDown;

        //  colors for snake and food
        Color snakeHeadColor = Color.White;
        Color snakeBodyColor = Color.Chartreuse;

        Color foodColor = Color.Yellow;


        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;

            new Settings();  // we r directly calling the setting class 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void KeyIsDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Left && Settings.Directions!="right") // != RIGHT is liay kiya q kkh agr hm LEFT ja rhy hain to right nhi ja skty up and down ja kty hain sirf
            {
                goLeft = true;
            }
            if (e.KeyCode == Keys.Right && Settings.Directions != "left") // != LEFT is liay kiya q kkh agr hm RIGHT ja rhy hain to left nhi ja skty up and down ja kty hain sirf
            {
                goRight = true;
            }
            if (e.KeyCode == Keys.Up && Settings.Directions != "down") // != down is liay kiya q kkh agr hm UP ja rhy hain to DOWN nhi ja skty up and down ja kty hain sirf
            {
                goUp = true;
            }
            if (e.KeyCode == Keys.Down && Settings.Directions != "up") // != Up is liay kiya q kkh agr hm DOWN ja rhy hain to UP nhi ja skty up and down ja kty hain sirf
            {
                goDown = true;
            }
            if (e.KeyCode == Keys.Space)
            {
                if (gameTimer.Enabled)
                    gameTimer.Stop();   // Pause
                else
                    gameTimer.Start();  // Resume
            }


        }

        private void KeyIsUp(object sender, KeyEventArgs e) // yahan key jo hai wo release ho jati hai na is liay yahan sb ko false kr dain gy
        {
            if (e.KeyCode == Keys.Left) 
            {
                goLeft = false;
            }
            if (e.KeyCode == Keys.Right) 
            {
                goRight = false;
            }
            if (e.KeyCode == Keys.Up) 
            {
                goUp = false;
            }
            if (e.KeyCode == Keys.Down) 
            {
                goDown = false;
            }
        }

        private void StartGame(object sender, EventArgs e)
        {
            RestartGame();

        }

        private void GameTimerEvent(object sender, EventArgs e)
        {
            //setting the directions
            if(goLeft)
            {
                Settings.Directions = "left";
            }
            if (goRight)
            {
                Settings.Directions = "right";
            }
            if (goUp)
            {
                Settings.Directions = "up";
            }
            if (goDown)
            {
                Settings.Directions = "down";
            }

            //end of directions
            for(int i=Snake.Count-1; i>=0; i--)
            {
                if(i==0)//head part of snake
                {
                    switch(Settings.Directions)
                    {
                        case "left":
                            Snake[i].X--;
                            break;
                        case "right":
                            Snake[i].X++;
                            break;
                        case "up":
                            Snake[i].Y--;
                            break;
                        case "down":
                                Snake[i].Y++;
                            break;
                    }

                    // agr ak edge sy nikl jaiy to dosry sy snake aa jaiy
                    if (Snake[i].X <0)
                    {
                        Snake[i].X = maxWidth;
                    }
                    if (Snake[i].X > maxWidth)
                    {
                        Snake[i].X = 0;
                    }

                    if (Snake[i].Y < 0)
                    {
                        Snake[i].Y = maxHeight;
                    }
                    if (Snake[i].Y > maxHeight)
                    {
                        Snake[i].Y = 0;
                    }

                    if (Snake[i].X ==  Food.X && Snake[i].Y == Food.Y)
                    {
                        EatFood();
                    }

                    // ye loop is liay kh agr snake apny kisi body part ko chu ly to game end ho jaiy
                    for(int j=1;j<Snake.Count;j++)
                    {
                        if (Snake[i].X == Snake[j].X && Snake[i].Y == Snake[j].Y)
                        {
                            GameOver();

                        }
                    }


                }
                else
                {
                    Snake[i].X = Snake[i - 1].X;
                    Snake[i].Y = Snake[i - 1].Y;
                }
            }

            picCanvas.Invalidate(); //it will clear everything from the canvas 


        }

        private void UpdatePicBoxGraphics(object sender, PaintEventArgs e)
        {
            Graphics canvas = e.Graphics;

            for (int i = 0; i < Snake.Count; i++)
            {
                Brush snakeBrush = new SolidBrush(i == 0 ? snakeHeadColor : snakeBodyColor);

                canvas.FillEllipse(snakeBrush, new Rectangle(
                    Snake[i].X * Settings.Width,
                    Snake[i].Y * Settings.Height,
                    Settings.Width,
                    Settings.Height
                ));
            }

            Brush foodBrush = new SolidBrush(foodColor);

            canvas.FillEllipse(foodBrush, new Rectangle(
                Food.X * Settings.Width,
                Food.Y * Settings.Height,
                Settings.Width,
                Settings.Height
            ));
        }

        private void lblHighScore_Click(object sender, EventArgs e)
        {

        }

        private void lblScore_MouseEnter(object sender, EventArgs e)
        {
            lblScore.ForeColor= Color.Yellow;
        }

        private void lblHighScore_MouseEnter(object sender, EventArgs e)
        {
            lblHighScore.ForeColor= Color.Yellow;
        }

        private void lblHighScore_MouseLeave(object sender, EventArgs e)
        {
            lblHighScore.ForeColor = Color.Lime;
        }

        private void lblScore_MouseLeave(object sender, EventArgs e)
        {
            lblScore.ForeColor = Color.Lime;
        }

        private void btnInstructions_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                            "SNAKE GAME INSTRUCTIONS:\n\n" +
                            "• Use Arrow Keys to move the snake.\n" +
                            "• Eat the food to grow.\n" +
                            "• Avoid hitting your own body.\n" +
                            "• Click Pause button to pause your Game.\n" +
                            "• Click the Start Button to begin.",
                            "Instructions",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
            );

        }

        private void cmbLevels_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cmbLevels.Text == "Low")
            //    gameTimer.Interval = 120;    // slow speed

            //else if (cmbLevels.Text == "Medium")
            //    gameTimer.Interval = 80;     // normal speed

            //else if (cmbLevels.Text == "High")
            //    gameTimer.Interval = 40;     // fast speed
        }


        private void grplevels_Enter(object sender, EventArgs e)
        {
            
        }

        private void rdoLow_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rdoMedium_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void rdoHigh_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void picCanvas_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem13_Click(object sender, EventArgs e)
        {

        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            pnlMainMenu.Visible = false;
            pnlInstructions.Visible = false;
        }

        private void btnInstructions_Click_1(object sender, EventArgs e)
        {
            pnlInstructions.Visible = true;
            pnlMainMenu.Visible = false;
        }

        private void pnlInstructions_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnBack(object sender, EventArgs e)
        {

        }

        private void btnBackToMain_Click(object sender, EventArgs e)
        {
            pnlMainMenu.Visible = true;
            pnlInstructions.Visible = false;
        }

        private void mniFormatColorsSnakeColorWhite_Click(object sender, EventArgs e)
        {
            snakeHeadColor = Color.White;
            snakeBodyColor = Color.White;
        }

        private void mniFormatColorsSnakeColorYellow_Click(object sender, EventArgs e)
        {
            snakeHeadColor = Color.Yellow;
            snakeBodyColor = Color.Yellow;
        }

        private void mniFormatColorsSnakeColorRed_Click(object sender, EventArgs e)
        {
            snakeHeadColor = Color.Red;
            snakeBodyColor = Color.Red;
        }

        private void mniFormatColorsSnakeColorBlue_Click(object sender, EventArgs e)
        {
            snakeHeadColor = Color.Blue;
            snakeBodyColor = Color.Blue;
        }

        private void mniFormatColorsSnakeColorPurple_Click(object sender, EventArgs e)
        {
            snakeHeadColor = Color.Purple;
            snakeBodyColor = Color.Purple;
        }

        private void mniFormatColorsFoodColorWhite_Click(object sender, EventArgs e)
        {
            foodColor = Color.White;
        }

        private void mniFormatColorsFoodColorYellow_Click(object sender, EventArgs e)
        {
            foodColor = Color.Yellow;
        }

        private void mniFormatColorsFoodColorBlue_Click(object sender, EventArgs e)
        {
            foodColor = Color.Blue;
        }

        private void mniFormatColorsFoodColorPurple_Click(object sender, EventArgs e)
        {
            foodColor = Color.Purple;
        }

        private void mniFormatColorsFoodColorRed_Click(object sender, EventArgs e)
        {
            foodColor = Color.Red;
        }
        
        private void easyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gameTimer.Interval = 90;
        }

        private void mediumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gameTimer.Interval = 40;
        }

        private void hardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            gameTimer.Interval = 15;
        }

        private void mniGamePause_Click(object sender, EventArgs e)
        {
            gameTimer.Stop();
        }

        private void mniGameResume_Click(object sender, EventArgs e)
        {
            gameTimer.Start();
        }

        private void mnuMain_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        //exit ka
        private void mniGameExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                 "Do you want to exit the game?",
                 "Exit",
                 MessageBoxButtons.YesNo,
                 MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
                Application.Exit();

        }

        private void btnStart_MouseEnter(object sender, EventArgs e)
        {
            btnStart.ForeColor = Color.Yellow;
        }

        private void btnStart_MouseLeave(object sender, EventArgs e)
        {
            btnStart.ForeColor = Color.Lime;
        }


        //Functions
        private void RestartGame()
        {
            btnStart.ForeColor = Color.Lime;
            //btnStart.BackColor= Color.Navy;
            maxWidth = picCanvas.Width / Settings.Width - 1;
            maxHeight = picCanvas.Height / Settings.Height - 1;

            Snake.Clear();

            btnStart.Enabled = false;

            score = 0;
            lblScore.Text="SCORE " + score;
            
            Circle Head = new Circle { X= 10, Y= 5 };
            Snake.Add(Head); // adding the head part of the snake to the list


            //add another 10 bodypart to the snake
            for (int i = 0; i < 3; i++) // change snake segments
            {
                Circle body = new Circle
                {
                    X = Snake[0].X - i,
                    Y = Snake[0].Y
                };
                Snake.Add(body);
            }

            Food = new Circle { X = rand.Next(2, maxWidth) , Y = rand.Next(2, maxHeight) }; 
            gameTimer.Start();
        }

        private void EatFood()
        {
            // increases scores
            score += 10;
            lblScore.Text = "SCORE : " + score;
            Circle body = new Circle
            {
                X = Snake[Snake.Count - 1].X,
                Y = Snake[Snake.Count - 1].Y
            };
            Snake.Add(body);

            Food = new Circle { X = rand.Next(2, maxWidth), Y = rand.Next(2, maxHeight) };


        }

        private void GameOver()
        {
            gameTimer.Stop();
            btnStart.Enabled = false;

            if(score> Highscore )
            {
                Highscore=score;
                lblHighScore.Text= "HIGHEST SCORE : " + Highscore;

                lblHighScore.ForeColor = Color.Maroon;
                lblHighScore.TextAlign=ContentAlignment.MiddleCenter;
            }
            MessageBox.Show("Game Over" + ", Score : " + score);

        }
    }
}
